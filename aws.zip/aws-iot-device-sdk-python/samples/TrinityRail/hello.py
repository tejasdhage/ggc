import time
import sys

file1=None
def printHelloWorld():
    global file1
    i=0
    while(True):
        print("Hello World")
        time.sleep(3)

printHelloWorld()