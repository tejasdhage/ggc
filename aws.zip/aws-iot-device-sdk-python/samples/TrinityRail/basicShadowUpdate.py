'''
/*
 * Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */
 '''

from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTShadowClient
import sys
import logging
import time
import json
import argparse
import os
import re
import DataSimulator
from itertools import cycle
from datetime import datetime, timedelta

from pytz import timezone

from AWSIoTPythonSDK.core.greengrass.discovery.providers import DiscoveryInfoProvider
from AWSIoTPythonSDK.core.protocol.connection.cores import ProgressiveBackOffCore
from AWSIoTPythonSDK.exception.AWSIoTExceptions import DiscoveryInvalidRequestException


# Shadow JSON schema:
#
# Name: Bot
# {
#	"state": {
#		"desired":{
#			"property":<INT VALUE>
#		}
#	}
# }


def allAreOver(getDataFromSimulator):
    i = 0
    flag = False
    while i < len(getDataFromSimulator):
        if getDataFromSimulator[i] == -1:
            flag = True
        else:
            return False
    return flag

# Custom Shadow callback
def customShadowCallback_Update(payload, responseStatus, token):
    # payload is a JSON string ready to be parsed using json.loads(...)
    # in both Py2.x and Py3.x
    if responseStatus == "timeout":
        print("Update request " + token + " time out!")
    if responseStatus == "accepted":
        payloadDict = json.loads(payload)
        print("~~~~~~~~~~~~~~~~~~~~~~~")
        #print("Update request with token: " + token + " accepted!")
        print("Rail Id: " + str(payloadDict["state"]["reported"]))
        print("~~~~~~~~~~~~~~~~~~~~~~~\n\n")
    if responseStatus == "rejected":
        print("Update request " + token + " rejected!")

# def customShadowCallback_Delete(payload, responseStatus, token):
#     if responseStatus == "timeout":
#         print("Delete request " + token + " time out!")
#     if responseStatus == "accepted":
#         print("~~~~~~~~~~~~~~~~~~~~~~~")
#         print("Delete request with token: " + token + " accepted!")
#         print("~~~~~~~~~~~~~~~~~~~~~~~\n\n")
#     if responseStatus == "rejected":
#         print("Delete request " + token + " rejected!")

# Read in command-line parameters

#RCB
parser = argparse.ArgumentParser()
# parser.add_argument("-e", "--endpoint", action="store", required=True, dest="host", help="Your AWS IoT custom endpoint")
# parser.add_argument("-r", "--rootCA", action="store", required=True, dest="rootCAPath", help="Root CA file path")
# parser.add_argument("-c", "--cert", action="store", dest="certificatePath", help="Certificate file path")
# parser.add_argument("-k", "--key", action="store", dest="privateKeyPath", help="Private key file path")
parser.add_argument("-p", "--port", action="store", dest="port", type=int, help="Port number override")
parser.add_argument("-w", "--websocket", action="store_true", dest="useWebsocket", default=False,
                     help="Use MQTT over WebSocket")
# parser.add_argument("-s", "--shardId", action="store", dest="shardId", default="1", help="Targeted shard id")
# parser.add_argument("-n", "--thingName", action="store", dest="thingName", default="Bot", help="Targeted thing name")
# parser.add_argument("-id", "--clientId", action="store", dest="clientId", default="basicShadowUpdater", help="Targeted client id")
# 
args = parser.parse_args()
# host = args.host
# rootCAPath = args.rootCAPath
# certificatePath = args.certificatePath
# privateKeyPath = args.privateKeyPath
port = args.port
useWebsocket = args.useWebsocket
# thingName = args.thingName
# clientId = args.clientId
# shardId = args.shardId
# 
# if args.useWebsocket and args.certificatePath and args.privateKeyPath:
#     parser.error("X.509 cert authentication and WebSocket are mutual exclusive. Please pick one.")
#     exit(2)
# 
# if not args.useWebsocket and (not args.certificatePath or not args.privateKeyPath):
#     parser.error("Missing credentials for authentication.")
#     exit(2)
# 
# # Port defaults
if args.useWebsocket and not args.port:  # When no port override for WebSocket, default to 443
    port = 443
if not args.useWebsocket and not args.port:  # When no port override for non-WebSocket, default to 8883
    port = 8883
#RCB

params=[

    {
        "endpoint":"aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA":"certs/root-ca-cert.pem",
        "cert":"certs/Train1_Dev/647e79ae6e.cert.pem",
        "key":"certs/Train1_Dev/647e79ae6e.private.key",
        "thingName":"Train1_Dev",
        "clientId":"Train1_Dev",
        "shardId":"key1",
        "trainId":"rail-1"
    },
    {
        "endpoint":"aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA":"certs/root-ca-cert.pem",
        "cert":"certs/Train2_Dev/b2e5c775d8.cert.pem",
        "key":"certs/Train2_Dev/b2e5c775d8.private.key",
        "thingName":"Train2_Dev",
        "clientId":"Train2_Dev",
        "shardId":"key1",
        "trainId":"rail-2"
    },
    {
        "endpoint":"aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA":"certs/root-ca-cert.pem",
        "cert":"certs/Train3_Dev/0ac9b5df21.cert.pem",
        "key":"certs/Train3_Dev/0ac9b5df21.private.key",
        "thingName":"Train3_Dev",
        "clientId":"Train3_Dev",
        "shardId":"key1",
        "trainId":"rail-3"
    },
    {
        "endpoint": "aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA": "certs/root-ca-cert.pem",
        "cert": "certs/Train4_Dev/dac0c6ac48.cert.pem",
        "key": "certs/Train4_Dev/dac0c6ac48.private.key",
        "thingName": "Train4_dev",
        "clientId": "Train4_dev",
        "shardId": "key1",
        "trainId":"rail-4"
    },
    {
        "endpoint": "aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA": "certs/root-ca-cert.pem",
        "cert": "certs/Train5_Dev/4d7ee6af98.cert.pem",
        "key": "certs/Train5_Dev/4d7ee6af98.private.key",
        "thingName": "Train5_dev",
        "clientId": "Train5_dev",
        "shardId": "key1",
        "trainId":"rail-5"
    },
    {
        "endpoint": "aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA": "certs/root-ca-cert.pem",
        "cert": "certs/Train6_Dev/a130a3495e.cert.pem",
        "key": "certs/Train6_Dev/a130a3495e.private.key",
        "thingName": "Train6_dev",
        "clientId": "Train6_dev",
        "shardId": "key1",
        "trainId":"rail-6"
    },
    {
        "endpoint": "aatsogndha50h-ats.iot.us-east-1.amazonaws.com",
        "rootCA": "certs/root-ca-cert.pem",
        "cert": "certs/Train7_Dev/533bdf35ee.cert.pem",
        "key": "certs/Train7_Dev/533bdf35ee.private.key",
        "thingName": "Train7_dev",
        "clientId": "Train7_dev",
        "shardId": "key1",
        "trainId":"rail-7"
    }
]




# Configure logging
logger = logging.getLogger("AWSIoTPythonSDK.core")
logger.setLevel(logging.DEBUG)
streamHandler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
streamHandler.setFormatter(formatter)
logger.addHandler(streamHandler)

# Init AWSIoTMQTTShadowClient
myAWSIoTMQTTShadowClient = [None,None,None,None,None,None,None]

counter=0
while counter<7:
    clientId=params[counter]["clientId"]
    host=params[counter]["endpoint"]
    rootCAPath=params[counter]["rootCA"]
    privateKeyPath=params[counter]["key"]
    certificatePath=params[counter]["cert"]
    if useWebsocket:
        myAWSIoTMQTTShadowClient[counter] = AWSIoTMQTTShadowClient(clientId, useWebsocket=True)
        myAWSIoTMQTTShadowClient[counter].configureEndpoint(host, port)
        myAWSIoTMQTTShadowClient[counter].configureCredentials(rootCAPath)
    else:
        myAWSIoTMQTTShadowClient[counter] = AWSIoTMQTTShadowClient(clientId)
        myAWSIoTMQTTShadowClient[counter].configureEndpoint(host, port)
        myAWSIoTMQTTShadowClient[counter].configureCredentials(rootCAPath, privateKeyPath, certificatePath)

    # AWSIoTMQTTShadowClient configuration
    myAWSIoTMQTTShadowClient[counter].configureAutoReconnectBackoffTime(1, 32, 20)
    myAWSIoTMQTTShadowClient[counter].configureConnectDisconnectTimeout(10)  # 10 sec
    myAWSIoTMQTTShadowClient[counter].configureMQTTOperationTimeout(5)  # 5 sec

    # Connect to AWS IoT
    myAWSIoTMQTTShadowClient[counter].connect()
    counter=counter+1


# Create a deviceShadow with persistent subscription
#RCB
#deviceShadowHandler = myAWSIoTMQTTShadowClient.createShadowHandlerWithName(thingName, True)
#RCB

endTime=[None,None,None,None,None,None,None]
latLonArray=[None,None,None,None,None,None,None]
temperatureArray=[None,None,None,None,None,None,None]
deviceShadowHandler=[]

startTime=None

counter=0
while counter < 7:
    thingName=params[counter]["thingName"]
    deviceShadowHandler.append(myAWSIoTMQTTShadowClient[counter].createShadowHandlerWithName(thingName, True))
    trainId = railId = params[counter]["trainId"]

    us_Pacific = timezone('US/Pacific')
    staticTime = datetime.now(us_Pacific)
    startTime = datetime(year=staticTime.year, month=staticTime.month, day=staticTime.day, hour=staticTime.hour,
                         minute=staticTime.minute, second=staticTime.second)

    speed = 50
    endTime[counter], latLonArray[counter], temperatureArray[counter] = DataSimulator.getAllReqParameters(startTime, speed, railId)

    counter=counter+1

getDataFromSimulator=[0,0,0,0,0,0,0]
indexes=[0,0,0,0,0,0,0]
while(True):
    counter=0
    while counter < 7:
        trainId=params[counter]["trainId"]
        shardId=params[counter]["shardId"]
        print(trainId)
        if getDataFromSimulator[counter] != -1:
            getDataFromSimulator[counter] = DataSimulator.genNewDataWithTS2(trainId, 3, startTime, endTime[counter], latLonArray[counter], indexes[counter], shardId,temperatureArray[counter])
            if getDataFromSimulator[counter] == -1:
                print()
            else:
                JSONPayload = '{"state":{"reported":' + getDataFromSimulator[counter] + '}}'
                #print("Simulator Count : "+getDataFromSimulator[counter])
                deviceShadowHandler[counter].shadowUpdate(JSONPayload, customShadowCallback_Update, 5)
                indexes[counter]=indexes[counter]+1
        counter = counter + 1
        time.sleep(2)

    over=allAreOver(getDataFromSimulator)
    if over==True:
        break
    startTime = startTime + timedelta(seconds=15)
                
                



# Delete shadow JSON doc
# deviceShadowHandler.shadowDelete(customShadowCallback_Delete, 5)

# Update shadow in a loop
# Create a deviceShadow with persistent subscription
# deviceShadowHandler = myAWSIoTMQTTShadowClient.createShadowHandlerWithName(thingName, True)

# This loop simulates a traffic light cycling between G, Y, R by updating the desired property in the shadow
# This uses the desired property because the light GGAD will get the request for changing and update the reported property
# The idea is the desired property is a request to update the light while the reported property is the actual value of the light

#startTime = datetime(2019, 9, 25, 1, 0, 0, 0)



#RCB
# railId=thingName.replace("Train","rail-")
# railId=railId.replace("_Dev","")
# railId=railId.replace("_dev","")
# trainId=railId
#RCB


# test_list = ["Train1_Dev", "Train2_Dev", "Train3_Dev", "Train4_dev", "Train5_dev","Train6_dev","Train7_dev"]
#
# sleep_time = test_list.index(thingName)
#
# if(sleep_time >= 8):
#     sleep_time = sleep_time + 1
# else:
#     sleep_time = sleep_time + 2

#RCB
# us_Pacific = timezone('US/Pacific')
# staticTime=datetime.now(us_Pacific)
# startTime = datetime(year=staticTime.year,month=staticTime.month,day=staticTime.day,hour=staticTime.hour,minute=staticTime.minute,second=staticTime.second)
# 
# speed = 50
# endTime, latLonArray, temperatureArray= DataSimulator.getAllReqParameters(startTime, speed, railId)
# i = 0
#RCB

# if shardId == "shard1":
#     trainId = "rail-1"
# else:
#     trainId = "rail-2"

#RCB
# while(1):
#     getDataFromSimulator = DataSimulator.genNewDataWithTS2(trainId, 3, startTime, endTime, latLonArray, i,shardId, temperatureArray)
#     if getDataFromSimulator == -1:
#         break
#     else:
#         JSONPayload = '{"state":{"reported":'+getDataFromSimulator+'}}'
#         deviceShadowHandler.shadowUpdate(JSONPayload, customShadowCallback_Update, 5)
#         startTime = startTime + timedelta(seconds=10)
#         i = i + 1
#         time.sleep(10)
#RCB
        
