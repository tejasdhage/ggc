import json
import random
from datetime import datetime, timedelta
from pytz import timezone

from os import path
import geopy.distance
import GetCurrentWeather

from pykml import parser


def getAllReqParameters(startTime, speed, railId):
    distance = calcDistReq(railId)

    timeReq = distance / speed
    timeReq = timeReq * 60 * 60
    endTime = startTime + timedelta(seconds=timeReq)

    actualSpeed = speed / (60.0 * 4.0)
    latLonArray = readLatLon(actualSpeed, railId)
    latlon = str(latLonArray[0]).split(",")
    lat = str(latlon[0])
    lon = (str(latlon[1]))
    temperatureArray = GetCurrentWeather.getCurrentTemperature(lat, lon)

    return endTime, latLonArray, temperatureArray


def calcDistReq(railId):
    pathStr = 'kmls/' + railId + '/' + railId + '.kml'
    kml_file = path.join(pathStr)

    with open(kml_file) as f:
        folder = parser.parse(f).getroot().Document.Folder

    coordinates = str(folder.Placemark.MultiGeometry.LineString.coordinates)

    a = coordinates.split(',0 ')

    latlon1 = str(a[0]).split(",")
    lat1 = latlon1[1]
    lon1 = latlon1[0]

    latlon2 = str(a[len(a) - 2]).split(",")
    lat2 = latlon2[1]
    lon2 = latlon2[0]

    coords_1 = (float(lat1), float(lon1))
    coords_2 = (float(lat2), float(lon2))

    distance = geopy.distance.vincenty(coords_1, coords_2).miles
    return distance


def readLatLon(reqDist, railId):
    pathStr = 'kmls/' + railId + '/' + railId + '.kml'
    kml_file = path.join(pathStr)

    with open(kml_file) as f:
        folder = parser.parse(f).getroot().Document.Folder

    coordinates = str(folder.Placemark.MultiGeometry.LineString.coordinates)

    a = coordinates.split(',0 ')

    i = 0
    j = 1
    k = 1
    strlen = len(a)

    latlon = str(a[i]).split(",")
    lat = latlon[1]
    lon = latlon[0]

    tempStr = "%s,%s" % (lat, lon)
    b = [tempStr]
    # b=[a[0]]

    while (i < strlen - 1 and k < strlen - 1):

        latlon1 = str(a[i]).split(",")
        lat1 = latlon1[1]
        lon1 = latlon1[0]

        latlon2 = str(a[k]).split(",")
        lat2 = latlon2[1]
        lon2 = latlon2[0]

        coords_1 = (float(lat1), float(lon1))
        coords_2 = (float(lat2), float(lon2))

        distance = geopy.distance.vincenty(coords_1, coords_2).miles

        if (distance < reqDist):
            k = k + 1
        else:
            tempStr = "%s,%s" % (lat2, lon2)
            b.append(tempStr)
            i = k
            k = k + 1
        j = j + 1

    latlon = str(a[len(a) - 2]).split(",")
    lat = latlon[1]
    lon = latlon[0]

    tempStr = "%s,%s" % (lat, lon)
    b.append(tempStr)
    return b


def genNewDataWithTS2(trainId, noOfContainers, startTime, endTime, latLonArray, i, shardId, temperature):
    weightOfBogie = 815610

    # temperature = GetCurrentWeather.getCurrentTemperature(latLonArray)

    latitude = 38.000000000000
    longitude = -77.999999999999

    batteryPower = [3.74, 3.7, 3.66, 3.62, 3.58, 3.54,
                    3.5, 3.54, 3.58, 3.62, 3.66, 3.7,
                    3.74, 3.78, 3.82, 3.86, 3.9, 3.94,
                    3.98, 3.94, 3.9, 3.86, 3.82, 3.78]

    us_Pacific = timezone('US/Pacific')
    staticTime = datetime.now(us_Pacific)
    startTime = datetime(year=staticTime.year, month=staticTime.month, day=staticTime.day, hour=staticTime.hour,
                         minute=staticTime.minute, second=staticTime.second)

    currentTime = startTime
    EventEnqueuedUtcTime = str(currentTime)

    cnt = 0

    containers = []
    weightUnit = "lbs"
    tempUnit = "Fahrenheit"
    x = {
        "railId": str(trainId),
        "weightUnit": weightUnit,
        "tempratureUnit": tempUnit,
        "shardId": shardId,
    }

    currentTime = startTime
    # if (currentTime <= endTime and i<len(latLonArray)):
    if (i < len(latLonArray)):
        c = 0
        containers = []

        currentTime2 = str(currentTime)

        timeSplit = currentTime2.split(' ')
        finalTime = timeSplit[0] + "T" + timeSplit[1]

        x["eventProcessedUtcTime"] = str(finalTime)

        currentHour = currentTime.hour

        currHrTemp = temperature[currentHour]
        nextHrTemp = temperature[(currentHour + 1) % 24]

        if (currHrTemp < nextHrTemp):
            increasing = 1
        elif (currHrTemp > nextHrTemp):
            increasing = -1
        else:
            increasing = 0

        secondsOver = currentTime - (
            datetime(currentTime.year, currentTime.month, currentTime.day, currentTime.hour, 0, 0, 0))

        secondsOver = secondsOver.total_seconds()

        while (c < noOfContainers):

            weightRandom = random.randrange(weightOfBogie, weightOfBogie + 10, 1)
            weightUnit = "lbs"
            # if (increasing == 1):
            # tempRandom = temperature[currentHour] + (secondsOver * 0.00416) / 15
            # elif (increasing == -1):
            # tempRandom = temperature[currentHour] - (secondsOver * 0.00416) / 15
            # else:
            tempRandom = random.uniform(int(temperature[currentHour]) - 0.5, int(temperature[currentHour]) + 0.5)

            # tempRandom = (tempRandom * 9.5 / 5.0) + 32.0
            tempRandom = round(tempRandom, 4)

            tempUnit = "Fahrenheit"

            latlon1 = str(latLonArray[i]).split(",")
            latRandom = latlon1[0]
            longRandom = latlon1[1]

            location = "" + str(latRandom) + "," + str(longRandom)

            powerRandom = round(random.uniform(batteryPower[currentHour] - 0.02,
                                               batteryPower[currentHour] + 0.02), 2)

            if (cnt % 120 == 0):
                done = False

            if (cnt % 120 != 0):
                done = True

            door = "N"
            if (done == True):
                door = "N"
            else:
                door = "Y"

            anomaly_temp=0
            anomaly_weight=0
            # ADDING ANOMALY FOR TEMPERATURE AND WEIGHT.
            if c==0 and i == 1 and trainId=="rail-1":
                tempRandom = 50
                anomaly_temp=1
            # elif i == 4:
            #     tempRandom=94
            # else:
            #     tempRandom=70
            if c==0 and i == 2 and trainId=="rail-2":
                weightRandom = 815655
                anomaly_weight=1
            # elif i==4:
            #     weightRandom=825620
            # else:
            #     weightRandom=800000
            #
            # if(i!=0 and i%60==0):
            #     weightRandom=random.randrange(100, 200, 1)

            container = {
                "carId": "car" + str(c + 1),
                "carWeight": str(weightRandom),
                "carTemperature": str(tempRandom),
                "currentLocation": str(location),
                "carBattery": str(powerRandom),
                "doorOpenClosedStatus": "N",
                "anomaly_temp":str(anomaly_temp),
                "anomaly_weight":str(anomaly_weight)
            }

            containers.append(container)
            cnt = cnt + 1
            c = c + 1

        i = i + 1
        x["cars"] = containers

        # print("Rwes", strX)
        # strX = strX.replace("'", "\\'")
        # print("Rwes",strX)
        return json.dumps(x)


    else:
        return -1
