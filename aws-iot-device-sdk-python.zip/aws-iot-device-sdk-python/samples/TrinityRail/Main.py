import DataSimulator
from datetime import datetime, timedelta
import time
import json

startTime = datetime(2017, 11, 28, 1, 0, 0, 0)
speed = 21
endTime, latLonArray, temperatureArray = DataSimulator.getAllReqParameters(startTime, speed)
shardId="key1"

i = 0
while (True):
    xStr = DataSimulator.genNewDataWithTS2("Texas", 3, startTime, endTime, latLonArray, i, shardId, temperatureArray)
    if (xStr == -1):
        break
    else:
        print(xStr)

        xStr=json.loads(xStr)

        weight_rail=xStr["cars"][0]["carWeight"]
        temperature_rail = xStr["cars"][0]["carTemperature"]

        battery_rail = xStr["cars"][0]["carBattery"]

        #print(weight_rail)
        #writeToCSV.writeDataToCSV(xStr)
    startTime = startTime + timedelta(seconds=15)
    time.sleep(0.5)
    i = i + 1
    if i>=5:
        break

print(i)