import paho.mqtt.client as mqtt
import subprocess, os, signal, psutil
import threading

p = [0,0,0,0,0,0,0]

p1 = None
p2 = None

def procFinal(index):
    d = ''
    global p
    privateKey=["certs/Train1_Dev/647e79ae6e.private.key","certs/Train2_Dev/b2e5c775d8.private.key","certs/Train3_Dev/0ac9b5df21.private.key","certs/Train4_Dev/dac0c6ac48.private.key","certs/Train5_Dev/4d7ee6af98.private.key","certs/Train6_Dev/a130a3495e.private.key","certs/Train7_Dev/533bdf35ee.private.key"]
    certs=["certs/Train1_Dev/647e79ae6e.cert.pem","certs/Train2_Dev/b2e5c775d8.cert.pem","certs/Train3_Dev/0ac9b5df21.cert.pem","certs/Train4_Dev/dac0c6ac48.cert.pem","certs/Train5_Dev/4d7ee6af98.cert.pem","certs/Train6_Dev/a130a3495e.cert.pem","certs/Train7_Dev/533bdf35ee.cert.pem"]
    if(index < 3):
        d = "_Dev"
    else:
        d = "_dev"

    command = 'python basicShadowUpdate.py --endpoint aatsogndha50h-ats.iot.us-east-1.amazonaws.com --rootCA certs/root-ca-cert.pem --cert '+certs[index]+' --key '+privateKey[index]+' --thingName Train'+str(index+1)+d+ ' --clientId Train'+str(index+1)+d+' --shardId shard1'
    print("Command : " + command)
    p[index]=subprocess.Popen(command,shell=True)
    print("Command : "+ command)
    print(p[index].pid)



def proc1():
    global p1
    p1 = subprocess.Popen(
        'python basicShadowUpdate.py --endpoint aatsogndha50h-ats.iot.us-east-1.amazonaws.com --rootCA root-ca-cert.pem --cert 647e79ae6e.cert.pem --key 647e79ae6e.private.key --thingName Train1_Dev --clientId Train1_Dev --shardId shard1',
        shell=True)
    print(p1.pid)


def proc2():
    global p2
    p2 = subprocess.Popen(
        'python basicShadowUpdate.py --endpoint aatsogndha50h-ats.iot.us-east-1.amazonaws.com --rootCA root-ca-cert.pem --cert b2e5c775d8.cert.pem --key b2e5c775d8.private.key --thingName Train2_Dev --clientId Train2_Dev --shardId shard2',
        shell=True)
    print(p2.pid)

def kill(proc_pid):
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()

def on_connect(client, userdata, flags, rc):  # The callback for when the client connects to the broker
    #print("Connected with result code {0}".format(str(rc)))  # Print result of connection attempt
    client.subscribe("action_dev")


def on_message(client, userdata, msg):  # The callback for when a PUBLISH message is received from the server.
    global p
    t=[None,None,None,None,None,None,None]
    print("Message received-> " + msg.topic + " " + str(msg.payload))  # Print a received msg
    if "1" in str(msg.payload):

        j=0
        while j < 6:
            t[j]=threading.Thread(target=procFinal,args=([j]))
            t[j].start()
            j=j+1



        # t1 = threading.Thread(target=proc1, args=())
        # t1.start()
        # t2 = threading.Thread(target=proc2, args=())
        # t2.start()
    else:
        print("In Else : ")
        print("In Else : ")
        j = 0
        while j < 6:
            print(p[j].pid)
            kill(p[j].pid)
            j = j + 1
        
        
        
        # print("In Else : ")
        # print("In Else : ")
        # print(p1.pid)
        # 
        # kill(p1.pid)
        # print(p2.pid)
        # kill(p2.pid)
        
        
        
        
        
        #os.killpg(os.getpgid(p.pid), signal.SIGTERM)

client = mqtt.Client("digi_mqtt_test")
client.on_connect = on_connect  # Define callback function for successful connection
client.on_message = on_message  # Define callback function for receipt of a message
# client.connect("m2m.eclipse.org", 1883, 60)  # Connect to (broker, port, keepalive-time)
client.connect('broker.hivemq.com', 1883)
client.loop_forever()  # Start networking daemon