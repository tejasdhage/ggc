import paho.mqtt.client as mqtt
import subprocess, os, signal, psutil
import threading

p1 = None
p2 = None


def print_square():
    global p1
    p1 = subprocess.Popen(
        'python HelloSquare.py',
        shell=True)
    print(p1.pid)

def print_cube():
    global p2
    p2 = subprocess.Popen(
        'python HelloCube.py',
        shell=True)
    print(p2.pid)



def kill(proc_pid):
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()


def on_connect(client, userdata, flags, rc):  # The callback for when the client connects to the broker
    # print("Connected with result code {0}".format(str(rc)))  # Print result of connection attempt
    client.subscribe("action2")


def on_message(client, userdata, msg):  # The callback for when a PUBLISH message is received from the server.

    print("Message received-> " + msg.topic + " " + str(msg.payload))  # Print a received msg
    if "1" in str(msg.payload):
        print("In IF")
        t1 = threading.Thread(target=print_square, args=())
        t1.start()
        t2 = threading.Thread(target=print_cube, args=())
        t2.start()
        #p = subprocess.Popen(
        #    'python TrainAShadowUpdate.py --endpoint aatsogndha50h-ats.iot.us-east-1.amazonaws.com --rootCA root-ca-cert.pem --cert db27887077.cert.pem --key db27887077.private.key --thingName Train1 --clientId Train1 --shardId key1',
        #    shell=True)
        #print(p.pid)
    else:
        print("In Else : ")
        print(p1.pid)

        kill(p1.pid)
        print(p2.pid)
        kill(p2.pid)
        # os.killpg(os.getpgid(p.pid), signal.SIGTERM)


client = mqtt.Client("digi_mqtt_test")
client.on_connect = on_connect  # Define callback function for successful connection
client.on_message = on_message  # Define callback function for receipt of a message
# client.connect("m2m.eclipse.org", 1883, 60)  # Connect to (broker, port, keepalive-time)
client.connect('mqtt.eclipse.org', 1883)
client.loop_forever()  # Start networking daemon