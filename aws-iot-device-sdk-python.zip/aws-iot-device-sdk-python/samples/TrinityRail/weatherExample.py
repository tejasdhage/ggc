import requests
from pprint import pprint


def getCurrentTemperature(latitude,longitude):
    API_key = "4e7573dd26e9b631ba5a8b3025a4db51"
    base_url = "api.openweathermap.org/data/2.5/forecast?lat=35&lon=139"

    latitude="40.306956"
    longitude="-75.12979799999999"
    # latitude = input("Enter Latitude : ")
    # longitude = input("Enter Longitude : ")

    Final_url = base_url + "appid=" + API_key + "&lat=" + latitude + "&lon=" + longitude
    Final_url="https://api.darksky.net/forecast/e500c008779cf735e3e2bd7fae5ae905/42.3601,-71.0589,1571384214?exclude=currently,flags,daily,minutely"
    weather_data = requests.get(Final_url).json()


    print("Weather Data:"+weather_data)
    #kelvinTemp=weather_data["main"]["temp"]

#getCurrentTemperature("0","0")
