import paho.mqtt.client as mqtt
import subprocess, os, signal, psutil
p = None

def kill(proc_pid):
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()

def on_connect(client, userdata, flags, rc):  # The callback for when the client connects to the broker
    print("Connected with result code " + format(str(rc)))  # Print result of connection attempt
    client.subscribe("action_dev")

def on_disconnect(client, userdata, flags, rc):  # The callback for when the client connects to the broker
    print("DisConnected with result code " + format(str(rc)))  # Print result of connection attempt


def on_message(client, userdata, msg):  # The callback for when a PUBLISH message is received from the server.
    global p
    print("Message received-> " + msg.topic + " " + str(msg.payload))  # Print a received msg
    if "1" in str(msg.payload):
        print("In IF")
        p = subprocess.Popen('sudo python basicShadowUpdate.py', shell=True)
        print(p.pid)
    else:
        print("In Else : ")
        print(p.pid)
        kill(p.pid)
        #os.killpg(os.getpgid(p.pid), signal.SIGTERM)

client = mqtt.Client("digi_mqtt_test")
client.on_connect = on_connect  # Define callback function for successful connection
client.on_message = on_message  # Define callback function for receipt of a message
client.on_disconnect = on_disconnect
# client.connect("m2m.eclipse.org", 1883, 60)  # Connect to (broker, port, keepalive-time)
client.connect('broker.hivemq.com', 1883)
client.loop_forever()  # Start networking daemon