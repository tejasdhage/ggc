from datetime import datetime, timedelta

import pytz
import requests
from pprint import pprint

from pytz import timezone



def getCurrentTemperature(latitude,longitude):
    API_key = "4e7573dd26e9b631ba5a8b3025a4db51"
    base_url = "api.openweathermap.org/data/2.5/forecast?lat=35&lon=139"

    # latitude="40.306956"
    # longitude="-75.12979799999999"
    # latitude = input("Enter Latitude : ")
    # longitude = input("Enter Longitude : ")

    #Final_url = base_url + "appid=" + API_key + "&lat=" + latitude + "&lon=" + longitude
    Final_url="https://api.darksky.net/forecast/e500c008779cf735e3e2bd7fae5ae905/"+latitude+","+longitude+"?exclude=currently,flags,daily,minutely"

    weather_data = requests.get(Final_url).json()


    #print("Weather Data:"+weather_data)
    #kelvinTemp=weather_data["main"]["temp"]

    temp=[0,0,0,0,0,0,
          0,0,0,0,0,0,
          0,0,0,0,0,0,
          0,0,0,0,0,0]
    i=False
    j=250
    for hourly in weather_data["hourly"]["data"]:


        totalSeconds=hourly["time"]
        dateInLocal = datetime.fromtimestamp(totalSeconds)
        #print(dateInLocal)
        #dateUTC=dateInLocal.utcnow()
        #dateInPST = dateUTC.astimezone(timezone('US/Pacific'))

        datePST=pytz.utc.localize(dateInLocal).astimezone(pytz.timezone('America/New_York'))
        # print(datePST)
        # print(dateInLocal)

        if datePST.hour == 0:
            i=not i
            if(i==True):
                j=0
            else:
                j=250

        if i==True and j<24:
            temp[datePST.hour]=hourly["temperature"]
        #print(str(i)+": "+str(hourly["time"]))
        #print(str(i)+": "+str(hourly["temperature"]))
        #print(dateUTC)



    #print(temp)
    return temp

#getCurrentTemperature("40.122091","-75.344238")
