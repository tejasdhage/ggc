import unittest

from test_factory import *
from test_helpers import *
from test_parser import *
from test_util import *

if __name__ == '__main__':
    unittest.main()